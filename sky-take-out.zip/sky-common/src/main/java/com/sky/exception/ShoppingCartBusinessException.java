package com.sky.exception;

public class ShoppingCartBusinessException extends BaseException {

    public ShoppingCartBusinessException(String msg) {
        super(msg);
    }

}
