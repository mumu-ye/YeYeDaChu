package com.sky.mapper;

import com.sky.entity.DishFlavor;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DishFlavorMapper {

    //批量插入口味数据
    void insertBatch(List<DishFlavor> flavors);
    //根据菜品id删除口味数据
    @Delete("DELETE FROM dish_flavor WHERE dish_id = #{dishId}")
    void deleteByDishId(Long dishId);
    //根据菜品id列表批量删除口味数据
    void deleteByDishIds(List<Long> dishIds);
    //根据菜品id获取口味数据
    @Select("SELECT * FROM dish_flavor WHERE dish_id = #{id}")
    List<DishFlavor> getByDishId(Long id);
}
